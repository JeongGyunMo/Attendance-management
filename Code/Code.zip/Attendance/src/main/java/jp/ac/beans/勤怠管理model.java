package jp.ac.beans;

import lombok.Data;
@Data
public class ����η��model {
	private String id;
	private String pass;
}
