package jp.ac.util;

import lombok.Data;

@Data
public class Accountinfo {
    private String id;
    private int grade;
    private String dateText;
    //ログインした人の情報
}
