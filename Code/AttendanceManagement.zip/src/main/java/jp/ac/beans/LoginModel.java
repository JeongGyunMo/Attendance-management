package jp.ac.beans;

import lombok.Data;
import lombok.RequiredArgsConstructor;
@Data
@RequiredArgsConstructor
public class LoginModel {
	private final String id; 			//社員ID;
	private final String passWord; 	//部署コード;
}
