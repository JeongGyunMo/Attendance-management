package jp.ac.beans;

import lombok.Data;
@Data
public class LoginModel {
	private String id; 			//社員ID;
	private String passWord; 	//部署コード;
}
