package jp.ac.beansTest;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class LoginModelTest {
	//given　準備
	//when　実行
	//then　結果
}
