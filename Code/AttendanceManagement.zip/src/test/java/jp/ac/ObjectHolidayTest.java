package jp.ac;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import jp.ac.beans.HolidayApplyModel;

class ObjectHolidayTest {
	
	HolidayApplyModel hVO = new HolidayApplyModel();
	

}
