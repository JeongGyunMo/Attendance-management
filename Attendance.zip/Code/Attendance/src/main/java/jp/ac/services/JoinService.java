package jp.ac.services;

import jp.ac.beans.joinbean;

public interface JoinService {
	
	public void Join(joinbean bean);
	
}
