package jp.ac.entities;

public class 勤怠管理TBLRepository {

}
