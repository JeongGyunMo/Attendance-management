package jp.ac.beans;

import lombok.Data;
@Data
public class joinbean {
	private String EMPLOYEE_ID;
	private String PASSWORD;
	private String EMPLOYEE_NUMBER;
	private String EMPLOYEE_NM;
}
