package jp.ac.beans;

import lombok.Data;
@Data
public class 勤怠管理model {
	private String id;
	private String pass;
}
